package com.example.news

import retrofit2.Response
import retrofit2.http.GET

interface MyApi {

    @GET("everything?sortBy=popularity&apiKey=fd6ce1ea8b9849ae818c55035ad0d9cf&q=apple&from=2024-03-04&pageSize=10")
    suspend fun getNews(): NewsResponse

}